(function(){"use strict";let r=window.location.hostname;if(r==="dewsecure.com"||r.endsWith(".dewsecure.com")||r==="localhost"||r==="127.0.0.1"){console.log("\u{1F6E1}\uFE0F [DewSecure] \u5B98\u65B9\u57DF\u540D\u4E0E\u672C\u5730\u73AF\u5883\uFF0C\u5DF2\u81EA\u52A8\u8DF3\u8FC7\u5185\u5BB9\u6E05\u7406\u3002");return}if(window.__dewsecureInjected)return;if(window.location.hostname.includes("wired.com")){console.warn("\u{1F6E1}\uFE0F [DewSecure] \u68C0\u6D4B\u5230 Wired\uFF0C\u5DF2\u81EA\u52A8\u8C41\u514D DOM \u6E05\u7406\u4EE5\u9632\u6B62 React \u6C34\u5408\u5931\u8D25\u3002");return}window.__dewsecureInjected=!0;let d=!1,i=d?console.warn.bind(console):()=>{},s=d?console.log.bind(console,"[DewSecure]"):()=>{},l=/(^|[-_])(ad|ads|advert|banner|popup|sponsor|promo|cookie|consent|push|tracking|tracker|ad-slot|ad-box|ad-wrap|ad-frame|ad-banner)([-_]|$)/i,g=/(verify|captcha|challenge|puzzle|recaptcha|hcaptcha|turnstile)/i;function k(e){try{chrome.runtime&&chrome.runtime.id&&chrome.runtime.sendMessage(e).catch(()=>{})}catch{}}function m(e){!e||e.dataset.dewsecureReported||(e.dataset.dewsecureReported="true",k({type:"DOM_AD_HIDDEN",url:window.location.href,tagName:e.tagName||"DIV"}))}function y(e,t){if(document.getElementById(t))return;let a=()=>{if(document.getElementById(t))return!0;let o=document.head||document.documentElement;return o?(o.appendChild(e),!0):!1};if(a())return;let n=new MutationObserver(()=>{a()&&n.disconnect()});n.observe(document.documentElement,{childList:!0,subtree:!0}),setTimeout(a,100)}function v(){let e=document.createElement("style");e.id="__dewsecure_style_1",e.textContent=`
            .ad-banner, .ad-container, .ad-slot, .ad-wrapper, .ad-unit,
            .ad-panel, .ad-box, .ad-frame, .ad-iframe, .ad-sticky, .ad-overlay,
            [data-ad], [data-ad-slot], [data-ad-unit], [data-google-query-id],
            ins.adsbygoogle, iframe[src*="doubleclick"], iframe[id*="google_ads_iframe"],
            .native-ad, .sponsored, .promoted, .advertisement {
                display: none !important;
                opacity: 0 !important;
                pointer-events: none !important;
                visibility: hidden !important;
            }
            #cookie-banner, .cookie-consent, [id*="cookie-notice"], [class*="cookie-banner"],
            .gdpr-banner, #gdpr, [class*="gdpr"], .consent-bar, .cookie-snackbar, .cookie-toast,
            #onetrust-consent-sdk, .optanon-alert-box-wrapper, #didomi-notice, #cookiebot,
            .cc-window, .cli-modal, .moove-gdpr-infobar, .borlabs-cookie-box,
            .exit-intent-popup, .exit-overlay, .newsletter-popup, .subscribe-box,
            .notification-prompt, .push-notification-bar, .app-download-banner,
            #onesignal-slidedown-container, .onesignal-slidedown-container,
            #pushcrew-chrome-style-notification, #webpushr-prompt-wrapper,
            #cleverpush-panel, .pushowl-notification-prompt, .fcm-notification-prompt,
            .smart-banner, .promo-banner, .promo-widget, .welcome-mat,
            .adblock-wall, .adblock-notice, .anti-adblock-overlay, .adblock-banner,
            .adblock-warning, .adblock-detected-modal {
                display: none !important;
                pointer-events: none !important;
            }
            .floating-ad, .video-ad, .google_ads_iframe, .OUTBRAIN, .taboola,
            .in-article-ad, .dfp-ad, .gpt-ad {
                display: none !important;
                pointer-events: none !important;
            }
            .social-widget, .social-bar, .share-bar, .twitter-share-button,
            .fb-like, .fb-share-button, .social-share-overlay {
                display: none !important;
            }
        `,y(e,"__dewsecure_style_1")}function _(){let e=document.createElement("style");e.id="__dewsecure_style_2",e.textContent=`
            #adLeaderboard, #adFrame, #ad-space, #ad-content, #ad-area, #ad-zone,
            #ad-panel, #adUnit, #adSlot, #adBox, #div-gpt-ad, #google_ads_frame,
            #adWrapper, #adBanner, #adContainer, #floating-ad, #popup-ad,
            #in-article-ad, #middle-ad, #left-ad, #right-ad, #top-ad, #sidebar-ad,
            #leaderboard-ad, #banner-ad, #ad-footer, #ad-header, #ad-sidebar,
            #ad-bottom, #ad-top, #advertisement, #ad-wrapper, #ad-slot,
            #ad-banner, #ad-container,
            .text-ad, .textad, .advertorial, .branded-content, .content-recommendation,
            .paid-content, .partner-content, .dianomi-ad, .adblade, .ntv-ad,
            .zergnet-widget, .rc-widget, .mgid-widget, .amazon-adsystem,
            .pubmatic-ad, .criteo-ad, .outbrain-widget, .trc_rbox,
            .google-ads, .google-ad, .adsbygoogle,
            .adverts, .advert, .adcontainer, .adslot, .adunit, .adblock,
            .affiliate-link, .shopping-ad, .product-listing-ad, .companion-ad,
            .postroll-ad, .midroll-ad, .preroll-ad,
            .social-icons-bar, .follow-widget, .adsbox, .adzone,
            [data-ad-source], [data-ad-provider], [data-adzone], [data-ad-placement],
            [data-ad-manager], [data-adunit], [data-dfp-ad], [data-ad-zone],
            [data-ad-id], [data-ad-network], [data-ad-format], [data-ad-size],
            [data-ad-position], [data-ad-type],
            [aria-label="sponsored"], [aria-label="ad"], [aria-label="advertisement"],
            .osano-cm-window, #iubenda-cs-banner, .cky-consent-container,
            #usercentrics-root, #truste-consent-track, #qc-cmp2-container,
            #sd-cmp, #evidon-banner, .fc-consent-root, #consent_blackbar,
            .securiti-cmp, .admiral-cmp, .sp_message_container,
            .cookie-top-bar, .floating-cookie-notice, .privacy-banner,
            #eu-cookie-law, .eu-cookie-law, .ccpa-banner, .generic-cookie-message,
            .generic-cookie-bar, .pipl-banner, .appi-banner, .rgpd-banner,
            .dsgvo-banner, .pdpa-banner, .popia-banner, .lgpd-banner,
            .cookie-notice, .cookie-consent,
            #pushowl-widget, #pushengage-subscribe, #aimtell-prompt,
            #optimonk-popup, #optimonk-popup-container,
            .notification-bell-widget, .push-bell, .push-notification-prompt,
            .adblock-modal,
            #ad-banner, #ad_banner, .ad_banner,
            #popup-ad, .popup-ad, #popupAd, .popupAd,
            #ad_overlay, .ad_overlay, #ad-overlay, .ad-overlay,
            #interstitial-ad, .interstitial-ad, #interstitialAd, .interstitialAd,
            #detected-popup, .detected-popup,
            #adblock-popup, .adblock-popup,
            #adblock-detected, .adblock-detected,
            #anti-adblock, .anti-adblock,
            #adexchanger, .adexchanger,
            div[data-ad-id], div[data-adzone], div[data-ad-client],
            iframe[src*="adexchangerapid"], iframe[src*="ntwkbc"], iframe[src*="usrpubtrk"],
            body > div[style*="position:fixed"][style*="z-index:9"],
            body > div[style*="position: fixed"][style*="z-index: 9"] {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        `,y(e,"__dewsecure_style_2")}let p=new Set,b=null;function E(){if(b=null,p.size===0)return;let e=Array.from(p);p.clear();for(let t of e)if(!(!t||!t.isConnected||t.dataset.dwKilled))try{l.test((t.className||"")+" "+(t.id||""))&&(t.style.setProperty("display","none","important"),t.dataset.dwKilled="true",m(t))}catch{}}let u=new Set,f=null;function A(){if(f=null,u.size===0)return;let e=Array.from(u);u.clear();for(let t of e)h(t)}function w(e){e&&(u.add(e),!f&&(f=setTimeout(A,50)))}function S(){if(["google.com","youtube.com","facebook.com","twitter.com","x.com","instagram.com","wired.com"].some(t=>window.location.hostname.endsWith(t))){console.log("\u{1F6E1}\uFE0F [DewSecure] \u6838\u5FC3\u7AD9\u70B9\u8C41\u514D DOM \u6E05\u7406\uFF0C\u9632\u6B62 SPA \u5D29\u6E83\u3002");return}try{chrome.runtime.sendMessage({type:"GET_SETTINGS"},t=>{if(chrome.runtime.lastError||!t)return;let a=window.location.hostname,n=o=>a===o||a.endsWith("."+o);((t.whitelist||[]).some(n)||(t.tempWhitelist||[]).some(n))&&(document.documentElement.setAttribute("data-dewsecure-paused","true"),console.log("\u{1F6E1}\uFE0F [DewSecure] \u547D\u4E2D\u767D\u540D\u5355\uFF0C\u5DF2\u505C\u6B62\u6CE8\u5165 CSS \u4E0E Hook\u3002"))})}catch{}setTimeout(()=>{if(document.documentElement.getAttribute("data-dewsecure-paused")==="true")return;v(),_(),new MutationObserver(a=>{for(let n of a)if(n.type==="childList")for(let o of n.addedNodes)o.nodeType===Node.ELEMENT_NODE&&w(o);else n.type==="attributes"&&n.target.nodeType===Node.ELEMENT_NODE&&(p.add(n.target),b||(b=setTimeout(E,80)))}).observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","id"]}),document.body&&w(document.body)},100)}if(window.location.hostname.includes("forbes.com")){let e=0,t=setInterval(()=>{let a=['a[href*="skip"]','button[class*="skip"]','[class*="welcome"] a[class*="continue"]','[id*="welcome"] a[class*="continue"]'];for(let o of a){let c=document.querySelector(o);if(c&&!c.dataset.dwClicked){c.click(),c.dataset.dwClicked="true";break}}document.querySelectorAll('[class*="welcome"], [class*="adblock"], [class*="overlay"], [id*="welcome"]').forEach(o=>{o.dataset.dwKilled||(o.style.setProperty("display","none","important"),o.remove(),o.dataset.dwKilled="true",m(o))}),document.querySelectorAll('article, main, .article-body, [class*="content"]').forEach(o=>{(o.style.display==="none"||o.style.visibility==="hidden")&&(o.style.setProperty("display","block","important"),o.style.setProperty("visibility","visible","important"))}),++e>20&&clearInterval(t)},500)}function h(e){if(!e)return;let t=e.querySelectorAll?e.querySelectorAll("div, iframe, ins, section, aside"):[];for(let a of t)if(!a.dataset.dwKilled)try{let n=window.getComputedStyle(a);if(n.position!=="fixed"&&n.position!=="absolute")continue;let o=a.getBoundingClientRect();if(!(o.width>window.innerWidth*.8&&o.height>window.innerHeight*.8))continue;let x=parseFloat(n.opacity)<.1||(a.innerText||"").trim()==="",T=parseInt(n.zIndex,10)||0;if(!x&&T<=1e3||g.test(a.className+a.id+a.innerText))continue;a.style.setProperty("pointer-events","none","important"),a.style.setProperty("display","none","important"),a.dataset.dwKilled="true",m(a),i("killed overlay")}catch{}e.shadowRoot&&h(e.shadowRoot)}S()})();chrome.runtime.onMessage.addListener((r,d,i)=>{if(r.type==="TOGGLE_PROTECTION"){if(r.enabled===!1){document.documentElement.setAttribute("data-dewsecure-paused","true");let s=document.getElementById("__dewsecure_style_1"),l=document.getElementById("__dewsecure_style_2");s&&s.remove(),l&&l.remove(),document.body&&(document.body.style.setProperty("overflow","auto","important"),document.documentElement.style.setProperty("overflow","auto","important")),console.warn("\u{1F6E1}\uFE0F [DewSecure] \u5DF2\u52A8\u6001\u6302\u8D77\uFF0C\u8FD8\u539F\u7F51\u9875\u72B6\u6001\u3002")}else location.reload();i({ok:!0})}});chrome.runtime.onMessage.addListener(r=>{if(r.type==="HIDE_AI_AD"&&r.domain){let d=r.domain;console.log(`\u{1F6E1}\uFE0F [DewSecure] \u6B63\u5728\u6267\u884C AI \u8F6F\u9690\u85CF: ${d}`),document.querySelectorAll("iframe").forEach(i=>{i.src&&i.src.includes(d)&&i.style.setProperty("display","none","important")}),document.querySelectorAll("script").forEach(i=>{if(i.src&&i.src.includes(d)){let s=i.parentElement;s&&(s.id.includes("ad")||s.className.includes("ad"))&&s.style.setProperty("display","none","important")}}),document.querySelectorAll("img").forEach(i=>{i.src&&i.src.includes(d)&&(i.style.setProperty("visibility","hidden","important"),i.style.setProperty("width","0","important"),i.style.setProperty("height","0","important"))})}});
