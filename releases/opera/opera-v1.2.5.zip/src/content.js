(function(){"use strict";if(["dewsecure.com","localhost","127.0.0.1"].includes(window.location.hostname)){console.log("\u{1F6E1}\uFE0F [DewSecure] \u5B98\u65B9\u57DF\u540D\u4E0E\u672C\u5730\u73AF\u5883\uFF0C\u5DF2\u81EA\u52A8\u8DF3\u8FC7\u5185\u5BB9\u6E05\u7406\u3002");return}if(window.__dewsecureInjected)return;if(window.location.hostname.includes("wired.com")){console.warn("\u{1F6E1}\uFE0F [DewSecure] \u68C0\u6D4B\u5230 Wired\uFF0C\u5DF2\u81EA\u52A8\u8C41\u514D DOM \u6E05\u7406\u4EE5\u9632\u6B62 React \u6C34\u5408\u5931\u8D25\u3002");return}window.__dewsecureInjected=!0;let d=!1,i=d?console.warn.bind(console):()=>{},f=d?console.log.bind(console,"[DewSecure]"):()=>{},s=/(^|[-_])(ad|ads|advert|banner|popup|sponsor|promo|overlay|modal|cookie|consent|push|tracking|tracker)([-_]|$)/i,c=/(verify|captcha|challenge|puzzle|recaptcha|hcaptcha|turnstile)/i;function w(t){try{chrome.runtime&&chrome.runtime.id&&chrome.runtime.sendMessage(t).catch(()=>{})}catch{}}function l(t){!t||t.dataset.dewsecureReported||(t.dataset.dewsecureReported="true",w({type:"DOM_AD_HIDDEN",url:window.location.href,tagName:t.tagName||"DIV"}))}function g(t,e){if(document.getElementById(e))return;let o=()=>{if(document.getElementById(e))return!0;let n=document.head||document.documentElement;return n?(n.appendChild(t),!0):!1};if(o())return;let a=new MutationObserver(()=>{o()&&a.disconnect()});a.observe(document.documentElement,{childList:!0,subtree:!0}),setTimeout(o,100)}function k(){let t=document.createElement("style");t.id="__dewsecure_style_1",t.textContent=`
            .ad-banner, .ad-container, .ad-slot, .ad-wrapper, .ad-unit,
            .ad-panel, .ad-box, .ad-frame, .ad-iframe, .ad-sticky, .ad-overlay,
            [data-ad], [data-ad-slot], [data-ad-unit], [data-google-query-id],
            ins.adsbygoogle, iframe[src*="doubleclick"], iframe[id*="google_ads_iframe"],
            .native-ad, .sponsored, .promoted, .advertisement {
                display: none !important;
                opacity: 0 !important;
                pointer-events: none !important;
                visibility: hidden !important;
            }
            #cookie-banner, .cookie-consent, [id*="cookie-notice"], [class*="cookie-banner"],
            .gdpr-banner, #gdpr, [class*="gdpr"], .consent-bar, .cookie-snackbar, .cookie-toast,
            #onetrust-consent-sdk, .optanon-alert-box-wrapper, #didomi-notice, #cookiebot,
            .cc-window, .cli-modal, .moove-gdpr-infobar, .borlabs-cookie-box,
            .exit-intent-popup, .exit-overlay, .newsletter-popup, .subscribe-box,
            .notification-prompt, .push-notification-bar, .app-download-banner,
            #onesignal-slidedown-container, .onesignal-slidedown-container,
            #pushcrew-chrome-style-notification, #webpushr-prompt-wrapper,
            #cleverpush-panel, .pushowl-notification-prompt, .fcm-notification-prompt,
            .smart-banner, .promo-banner, .promo-widget, .welcome-mat,
            .adblock-wall, .adblock-notice, .anti-adblock-overlay, .adblock-banner,
            .adblock-warning, .adblock-detected-modal {
                display: none !important;
                pointer-events: none !important;
            }
            .floating-ad, .video-ad, .google_ads_iframe, .OUTBRAIN, .taboola,
            .in-article-ad, .dfp-ad, .gpt-ad {
                display: none !important;
                pointer-events: none !important;
            }
            html, body {
                overflow: auto !important;
                position: static !important;
                touch-action: auto !important;
            }
            .social-widget, .social-bar, .share-bar, .twitter-share-button,
            .fb-like, .fb-share-button, .social-share-overlay {
                display: none !important;
            }
            html, body, #app, #root, .main-wrapper, #page-wrapper {
                overflow-y: visible !important;
                overflow-x: visible !important;
                position: static !important;
                height: auto !important;
                max-height: none !important;
            }
            body.no-scroll, body.modal-open, body.overflow-hidden, body.stopped,
            html.no-scroll, html.modal-open, html.overflow-hidden, html.stopped {
                overflow-y: auto !important;
                overflow-x: auto !important;
                position: static !important;
            }
        `,g(t,"__dewsecure_style_1")}function x(){let t=document.createElement("style");t.id="__dewsecure_style_2",t.textContent=`
            #adLeaderboard, #adFrame, #ad-space, #ad-content, #ad-area, #ad-zone,
            #ad-panel, #adUnit, #adSlot, #adBox, #div-gpt-ad, #google_ads_frame,
            #adWrapper, #adBanner, #adContainer, #floating-ad, #popup-ad,
            #in-article-ad, #middle-ad, #left-ad, #right-ad, #top-ad, #sidebar-ad,
            #leaderboard-ad, #banner-ad, #ad-footer, #ad-header, #ad-sidebar,
            #ad-bottom, #ad-top, #advertisement, #ad-wrapper, #ad-slot,
            #ad-banner, #ad-container,
            .text-ad, .textad, .advertorial, .branded-content, .content-recommendation,
            .paid-content, .partner-content, .dianomi-ad, .adblade, .ntv-ad,
            .zergnet-widget, .rc-widget, .mgid-widget, .amazon-adsystem,
            .pubmatic-ad, .criteo-ad, .outbrain-widget, .trc_rbox,
            .google-ads, .google-ad, .adsbygoogle,
            .adverts, .advert, .adcontainer, .adslot, .adunit, .adblock,
            .affiliate-link, .shopping-ad, .product-listing-ad, .companion-ad,
            .postroll-ad, .midroll-ad, .preroll-ad,
            .social-icons-bar, .follow-widget, .adsbox, .adzone,
            [data-ad-source], [data-ad-provider], [data-adzone], [data-ad-placement],
            [data-ad-manager], [data-adunit], [data-dfp-ad], [data-ad-zone],
            [data-ad-id], [data-ad-network], [data-ad-format], [data-ad-size],
            [data-ad-position], [data-ad-type],
            [aria-label="sponsored"], [aria-label="ad"], [aria-label="advertisement"],
            .osano-cm-window, #iubenda-cs-banner, .cky-consent-container,
            #usercentrics-root, #truste-consent-track, #qc-cmp2-container,
            #sd-cmp, #evidon-banner, .fc-consent-root, #consent_blackbar,
            .securiti-cmp, .admiral-cmp, .sp_message_container,
            .cookie-top-bar, .floating-cookie-notice, .privacy-banner,
            #eu-cookie-law, .eu-cookie-law, .ccpa-banner, .generic-cookie-message,
            .generic-cookie-bar, .pipl-banner, .appi-banner, .rgpd-banner,
            .dsgvo-banner, .pdpa-banner, .popia-banner, .lgpd-banner,
            .cookie-notice, .cookie-consent,
            #pushowl-widget, #pushengage-subscribe, #aimtell-prompt,
            #optimonk-popup, #optimonk-popup-container,
            .notification-bell-widget, .push-bell, .push-notification-prompt,
            .adblock-modal,
            #ad-banner, #ad_banner, .ad_banner,
            #popup-ad, .popup-ad, #popupAd, .popupAd,
            #ad_overlay, .ad_overlay, #ad-overlay, .ad-overlay,
            #interstitial-ad, .interstitial-ad, #interstitialAd, .interstitialAd,
            #detected-popup, .detected-popup,
            #adblock-popup, .adblock-popup,
            #adblock-detected, .adblock-detected,
            #anti-adblock, .anti-adblock,
            #adexchanger, .adexchanger,
            div[data-ad-id], div[data-adzone], div[data-ad-client],
            iframe[src*="adexchangerapid"], iframe[src*="ntwkbc"], iframe[src*="usrpubtrk"],
            body > div[style*="position:fixed"][style*="z-index:9"],
            body > div[style*="position: fixed"][style*="z-index: 9"] {
                display: none !important;
                visibility: hidden !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        `,g(t,"__dewsecure_style_2")}let p=new Set,m=null;function E(){if(m=null,p.size===0)return;let t=Array.from(p);p.clear();for(let e of t)if(!(!e||!e.isConnected||e.dataset.dwKilled))try{s.test((e.className||"")+" "+(e.id||""))&&(e.style.setProperty("display","none","important"),e.dataset.dwKilled="true",l(e))}catch{}}let u=new Set,b=null;function S(){if(b=null,u.size===0)return;let t=Array.from(u);u.clear();for(let e of t)_(e)}function h(t){t&&(u.add(t),!b&&(b=setTimeout(S,50)))}function T(){w({type:"GET_SETTINGS"}),setTimeout(()=>{let t=[];k(),x(),new MutationObserver(o=>{for(let a of o)if(a.type==="childList")for(let n of a.addedNodes)n.nodeType===Node.ELEMENT_NODE&&h(n);else a.type==="attributes"&&a.target.nodeType===Node.ELEMENT_NODE&&(p.add(a.target),m||(m=setTimeout(E,80)))}).observe(document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","id"]}),document.body&&(h(document.body),v()),setInterval(v,1500)},100)}function I(){document.body&&getComputedStyle(document.body).overflow==="hidden"&&document.body.style.setProperty("overflow","auto","important"),document.documentElement&&getComputedStyle(document.documentElement).overflow==="hidden"&&document.documentElement.style.setProperty("overflow","auto","important")}function v(){I();let t=document.querySelectorAll("div, section, iframe");for(let e of t)if(!e.dataset.dwKilled)try{let o=window.getComputedStyle(e);if(o.position==="fixed"&&(parseInt(o.zIndex)>9999||o.zIndex==="auto")){let a=e.getBoundingClientRect();if(a.width>window.innerWidth*.8&&a.height>window.innerHeight*.8){let n=(e.innerText||"").trim(),r=/(cookie|consent|privacy|gdpr|ccpa|pipl|appi|rgpd|pdpa|popia|onetrust|didomi|cookiebot|usercentrics|quantcast|liveramp|borlabs|moove|klaro|termly)/i.test(n+" "+e.className+" "+e.id);(n===""||parseFloat(o.opacity)<.1||r)&&(/(verify|captcha|challenge|puzzle|turnstile)/i.test(e.className+" "+e.id+" "+n)||(e.style.setProperty("display","none","important"),e.dataset.dwKilled="true",l(e),i("killed overlay/cmp mask")))}}}catch{}}function y(){let t=e=>{!e||!e.style||(e.style.setProperty("overflow-y","auto","important"),e.style.setProperty("overflow-x","auto","important"),e.style.setProperty("position","static","important"),e.style.setProperty("touch-action","auto","important"))};if(t(document.documentElement),document.body&&t(document.body),window.__dw_scroll_obs||(window.__dw_scroll_obs=new MutationObserver(()=>{t(document.documentElement),document.body&&t(document.body)}),window.__dw_scroll_obs.observe(document.documentElement,{attributes:!0,attributeFilter:["style","class"]}),document.body&&window.__dw_scroll_obs.observe(document.body,{attributes:!0,attributeFilter:["style","class"]})),!window.__dw_event_blocked){let e=o=>{(o.target===document||o.target===document.body)&&o.stopImmediatePropagation()};document.addEventListener("touchmove",e,{capture:!0,passive:!1}),document.addEventListener("wheel",e,{capture:!0,passive:!1}),window.__dw_event_blocked=!0}}if(y(),setTimeout(y,500),setTimeout(y,2e3),window.location.hostname.includes("forbes.com")){let t=0,e=setInterval(()=>{let o=['a[href*="skip"]','button[class*="skip"]','[class*="welcome"] a[class*="continue"]','[id*="welcome"] a[class*="continue"]'];for(let n of o){let r=document.querySelector(n);if(r&&!r.dataset.dwClicked){r.click(),r.dataset.dwClicked="true";break}}document.querySelectorAll('[class*="welcome"], [class*="adblock"], [class*="overlay"], [id*="welcome"]').forEach(n=>{n.dataset.dwKilled||(n.style.setProperty("display","none","important"),n.remove(),n.dataset.dwKilled="true",l(n))}),document.querySelectorAll('article, main, .article-body, [class*="content"]').forEach(n=>{(n.style.display==="none"||n.style.visibility==="hidden")&&(n.style.setProperty("display","block","important"),n.style.setProperty("visibility","visible","important"))}),++t>20&&clearInterval(e)},500)}function _(t){if(!t)return;let e=t.querySelectorAll?t.querySelectorAll("div, iframe, ins, section, aside"):[];for(let o of e)if(!o.dataset.dwKilled)try{let a=window.getComputedStyle(o);if(a.position!=="fixed"&&a.position!=="absolute")continue;let n=o.getBoundingClientRect();if(!(n.width>window.innerWidth*.8&&n.height>window.innerHeight*.8))continue;let z=parseFloat(a.opacity)<.1||(o.innerText||"").trim()==="",A=parseInt(a.zIndex,10)||0;if(!z&&A<=1e3||c.test(o.className+o.id+o.innerText))continue;o.style.setProperty("pointer-events","none","important"),o.style.setProperty("display","none","important"),o.dataset.dwKilled="true",l(o),i("killed overlay")}catch{}t.shadowRoot&&_(t.shadowRoot)}T()})();chrome.runtime.onMessage.addListener(d=>{if(d.type==="PHISHING_DETECTED"){if(document.getElementById("__dewsecure_phishing_wall"))return;let i=document.createElement("div");i.id="__dewsecure_phishing_wall",i.innerHTML=`
            <div style="position:fixed;top:0;left:0;width:100vw;height:100vh;background:#c0392b;color:white;z-index:2147483647;display:flex;flex-direction:column;justify-content:center;align-items:center;font-family:-apple-system,BlinkMacSystemFont,sans-serif;text-align:center;padding:20px;box-sizing:border-box;">
                <div style="font-size:80px;margin-bottom:20px;">\u26A0\uFE0F</div>
                <h1 style="font-size:36px;margin:0 0 16px 0;font-weight:bold;">\u6781\u5EA6\u5371\u9669\uFF1A\u9493\u9C7C\u7F51\u7AD9</h1>
                <p style="font-size:18px;max-width:600px;line-height:1.5;opacity:0.9;">DewSecure AI \u5F15\u64CE\u68C0\u6D4B\u5230\u8BE5\u7F51\u7AD9\u8BD5\u56FE\u4F2A\u88C5\u6210\u5408\u6CD5\u673A\u6784\uFF0C\u4EE5\u7A83\u53D6\u60A8\u7684\u5BC6\u7801\u3001\u4FE1\u7528\u5361\u6216\u4E2A\u4EBA\u4FE1\u606F\u3002\u4E3A\u4E86\u4FDD\u62A4\u60A8\u7684\u8D22\u4EA7\u5B89\u5168\uFF0C\u9875\u9762\u5DF2\u88AB\u5F3A\u5236\u9501\u5B9A\u3002</p>
                <button id="__dewsecure_ignore_phishing" style="margin-top:30px;padding:12px 24px;font-size:16px;border:none;border-radius:8px;background:rgba(255,255,255,0.2);color:white;cursor:pointer;">\u6211\u662F\u4E13\u5BB6\uFF0C\u5FFD\u7565\u98CE\u9669\u7EE7\u7EED\u8BBF\u95EE</button>
            </div>
        `,document.documentElement.appendChild(i),document.documentElement.style.setProperty("overflow","hidden","important"),document.getElementById("__dewsecure_ignore_phishing").onclick=()=>{i.remove(),document.documentElement.style.removeProperty("overflow")}}});chrome.runtime.onMessage.addListener((d,i,f)=>{if(d.type==="TOGGLE_PROTECTION"){if(d.enabled===!1){document.documentElement.setAttribute("data-dewsecure-paused","true");let s=document.getElementById("__dewsecure_style_1"),c=document.getElementById("__dewsecure_style_2");s&&s.remove(),c&&c.remove(),document.body&&(document.body.style.setProperty("overflow","auto","important"),document.documentElement.style.setProperty("overflow","auto","important")),window.postMessage({type:"DEWSECURE_PAUSE"},"*"),console.warn("\u{1F6E1}\uFE0F [DewSecure] \u5DF2\u52A8\u6001\u6302\u8D77\uFF0C\u8FD8\u539F\u7F51\u9875\u72B6\u6001\u3002")}else location.reload();f({ok:!0})}});
